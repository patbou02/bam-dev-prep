/*
Language: plaintext
Author: Egor Rogov (e.rogov@postgrespro.ru)
Description:
    Plain text without any highlighting.
*/

function(hljs) {
    return {
        disableAutodetect: true
    };
}
